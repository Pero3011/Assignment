<!-- 2. Inheritance
    Create a Member class that contains protected properties like
    (name, email, ID, borrow_limit)
    Create a subclass PremiumMember that inherits from Member
    and adds additional features (increase the borrowing limit) -->

<?php

//Creating a Member class
class Member {
    protected $name;
    protected $email;
    protected $ID;
    protected $borrow_limit;

    function __construct($name, $email, $ID,$borrow_limit)
    {
        $this->name = $name;
        $this->email = $email;
        $this->ID = $ID;


        if($borrow_limit<=3)
            $this->borrow_limit = $borrow_limit;
        else
            $this->borrow_limit = "Invalid borrow limit";
    }

    function getData(){
        return [$this->name, $this->email, $this->ID,$this->borrow_limit];
    }
}

//Creating a PremiumMember class that inherits from Member
class PremiumMember extends Member {
    
    function PremiumData($name, $email, $ID,$borrow_limit)
    {
        $this->name = $name;
        $this->email = $email;
        $this->ID = $ID;

        echo "You are a premium member your borrow limit is increased to 5\n";
        if($borrow_limit<=5)
            $this->borrow_limit = $borrow_limit;
        else
            $this->borrow_limit = "Invalid borrow limit";
    }
}

echo "your borrow limit is 3\n";
$member=new Member("John","john@example.com","123",2);
print_r($member->getData());
$premMember = new PremiumMember("John","john@example.com","123",5);
echo($premMember->PremiumData("Mariam", "lailia@gmail.com", "sfjh",4));
print_r($premMember->getData());

?>