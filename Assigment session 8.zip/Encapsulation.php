<?php

// Creating the class and its objects
class Book{
    private $title;
    private $author;
    private $ID;

    //setter method
    public function __construct($title,$author,$ID) {
        $this->title = $title;
        $this->author = $author;
        $this->ID = $ID;
      }

    //getter method
    public function get_items() {
        return [$this->title,$this->author,$this->ID];
      }
    }
    
    //calling the class and its objects
    $data = new book("A tale of two cities","Shekspeare","123IH1");
    print_r($data->get_items()) ;







?>