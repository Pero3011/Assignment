<!--4. Abstraction
    Create an abstract class Library with an abstract method
        displayRules().
    Implement this method in a PublicLibrary subclass.
-->

<?php

abstract class Library{
    abstract function displayRules();
}

class PublicLibrary extends Library{
    function displayRules(){
        echo "Public Library Rules:\n";
        echo "1. Be quiet.\n";
        echo "2. Return books on time.\n";
        }
}

$rules=new PublicLibrary();
$rules->displayRules();
?>